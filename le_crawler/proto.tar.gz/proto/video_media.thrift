// Copyright 2014 LeTV Inc. All Rights Reserved.
// Author: gaoqiang@letv.com (Qiang Gao)

include "crawl_doc.thrift"

namespace cpp pipeline
namespace java leso.media
namespace py leso.media

// the value of State must be power of 2 so that it can be used in AND and OR op.
enum State {
  NORMAL = 0,
  DEAD_LINK = 1,
  NO_MD5 = 2,
  LONG_VIDEO = 4,
}

//明星结构
struct Star {
  1:required string id;
  2:string name;
  3:string name_en;
  4:string name_cn;
  5:string name_other;
  6:string name_stage;
  7:string name_origin;
  8:string sex;
  9:string area;
  10:string birthday;
  11:string poster;
  12:string description;
  13:double col_rating;
  14:i64 commentator;
  15:string tags;
  16:string blood_type;
  17:string astro;
  18:string language;
  19:string nation;
  20:string height;
  21:string weight;
  22:string dead_date;
  23:string dead_desc;
  24:string professional;
  25:i64 create_time;
  26:i64 update_time;
  27:map<string, string> extend;
}

//自频道用户结构
struct OriginalUser {
  1:  optional string                         user_name;                      //用户名
  2:  optional string                         url;                            //用户频道url
  3:  optional string                         portrait_url;                   //用户头像
  4:  optional i32                            video_num;                      //视频数量
  5:  optional i64                            play_num;                       //视频播放数
  6:  optional i64                            fans_num;                       //粉丝数
  7:  optional string                         channel_desc;                   //频道介绍
  8:  optional i64                            update_time;                    //更新时间
  9:  optional string                         channel_id;                     //频道ID
  10: optional string                         channel_title;                  //标题
  11: optional string                         thumbnails;                     //缩略图(弃用)
  12: optional i64                            publish_time;                   //发布时间
  13: optional i32                            comment_num;                    //评论数
  14: optional list<crawl_doc.Thumbnail>      thumbnail_list;                 //缩略图
}

//视频结构
struct MediaVideo {
  1:  optional string                         id;                             //主键
  2:  optional string                         domain;                         //站点源
  3:  optional i32                            domain_id;                      //站点源id
  4:  optional string                         category;                       //分类，多个用';'分开
  5:  optional string                         category_id;                    //分类id，多个用';'分开
  6:  optional string                         title;                          //标题
  7:  optional string                         subtitle;                       //子标题
  8:  optional string                         title_other;                    //其他标题
  9:  optional string                         title_en;                       //英文标题
  10: optional string                         actor;                          //演员表|主持人|歌手|配音, 多个用“;”分开
  11: optional string                         actor_id;                       //演员id，多个用';'分开
  12: optional string                         director;                       //导演，多个用';'分开
  13: optional string                         director_id;                    //导演id
  14: optional string                         writer;                         //编剧
  15: optional string                         writer_id;                      //编剧id
  16: optional string                         showtime;                       //上映时间,网页原始数据
  17: optional i32                            showyear;                       //上映年份
  18: optional string                         area;                           //地区
  19: optional string                         subcategory;                    //子分类
  20: optional string                         subcategory_id;                 //子分类id
  21: optional string                         language;                       //语言
  22: optional i32                            language_id;                    //语言id
  23: optional string                         fit_age;                        //年龄分级
  24: optional string                         fit_age_id;                     //年龄分级id
  25: optional string                         short_desc;                     //简介
  26: optional string                         desc;                           //详情
  27: optional string                         tags;                           //标签
  28: optional string                         poster;                         //海报
  29: optional i64                            collects;                       //所在精选集，多个用';'分开
  30: optional double                         rating;                         //评分
  31: optional i32                            commentator;                    //评论人
  32: optional i32                            episodes;                       //集数
  33: optional i32                            is_end;                         //完结
  34: optional string                         url;                            //播放地址
  35: optional string                         quality;                        //画质
  36: optional string                         duration;                       //时长
  37: optional i32                            copyright;                      //是否有版权
  38: optional i32                            state;                          //是否可用，1为可用，0为不可用
  39: optional string                         type;                           //视频类型(正片，花絮、预告等等)
  40: optional i32                            type_id;                        //视频类型id
  41: optional string                         version;                        //版本号，当前为0.1
  42: optional i32                            version_id;                     //版本号id，当前为1
  43: optional i32                            is_pay;                         //是否收费，1为收费，0为免费
  44: optional i64                            play_day_total;                 //日播次数
  45: optional i64                            play_week_total;                //周播次数
  46: optional i64                            play_month_total;               //月播次数
  47: optional i64                            play_season_total;              //季播次数
  48: optional i64                            play_year_total;                //年播次数
  49: optional i64                            play_total;                     //播放总数
  50: optional i64                            create_time;                    //最新爬取时间
  51: optional i64                            update_time;                    //更新时间
  52: optional i64                            delete_time;                    //下架时间
  53: optional string                         platform_download;              //下载平台
  54: optional string                         platform_play;                  //播放平台
  55: optional string                         platform_pay;                   //付费平台
  56: optional string                         publish_status;                 //发行状态
  57: optional string                         douban_id;                      //豆瓣id
  59: optional string                         resolution;                     //分辨率
  60: optional i32                            is_edit;                        //是否可写，1为可写，0为只读
  61: optional map<string, string>            extend;                         //扩展字段
  62: optional string                         episode;                        //序号(整数/日期等)
  63: optional i32                            porder;                         //序号
  64: optional bool                           dup = 0;                        //是否冗余
  65: optional bool                           is_404 = 0;                     //是否为404
  66: optional bool                           is_soft404 = 0;                 //是否为软404
  67: optional string                         area_id;                        //地区id
  68: optional i64                            voteup_count = 0;               //点赞次数
  69: optional i64                            votedown_count = 0;             //点踩次数
  70: optional string                         play_trends;                    // -- DEPRECATED --   播放趋势，格式：create_time_1|play_total_1;create_time_2|play_total_2
  71: optional string                         category_list;                  //列表格式：a,b,c,d;a,b,c,f;h,j,k,m
  72: optional string                         crumbs;                         //播放页面包屑:a,b,c
  73: optional i64                            crawl_time;                     //最新爬取时间
  74: optional i64                            content_timestamp;              //视频上传时间戳
  75: optional i64                            duration_seconds;               //时长秒数
  76: optional list<string>                   OBSOLETE_inlink;                //入链
  77: optional list<string>                   OBSOLETE_outlink;               //出链
  78: optional State                          page_state = State.NORMAL;      // -- DEPRECATED --   状态
  79: optional crawl_doc.CrawlHistory         crawl_history;                  //爬取历史
  80: optional i64                            doc_id;                         //作用同id,只是i64版本
  81: optional i64                            discover_time;                  //爬虫发现该URL的时间戳
  82: optional list<crawl_doc.Anchor>         in_links;                       //入链
  83: optional OriginalUser                   user;                           //原创用户
  84: optional string                         playlist;                       //播放列表ID
  85: optional string                         dimension;                      //视频维度
  86: optional bool                           caption;                        //字幕
  87: optional i64                            comment_num;                    //评论数
  88: optional crawl_doc.SourceType           source_type;                    //来源：如自定义，YouTube精选，第三方网站等
  89: optional string                         thumbnails;                     //缩略图列表(弃用)
  90: optional i16                            content_quality;                //高质量.
  91: optional string                         player;                         //YouTube内嵌播放地址
  92: optional list<crawl_doc.Thumbnail>      thumbnail_list;                 //缩略图列表
  93: optional bool                           dead_link = 0;                  //视频url是否为死链
}

//专辑下的视频列表。尽量不存冗余，只存用于排序，筛选的字段.
struct MediaVideoAbstract {
  1:required string id;  //主键
  2:required string episode;
  3:required i32 porder;
  4:required i32 type_id;
  5:required i64 create_time;
  6:optional string title;
  7:optional string play_url;	//播放地址
}

//专辑结构
struct MediaAlbum {
  1:required string id;  //主键
  2:required string source;
  3:required i32 source_id;
  4:required string category;
  5:required i32 category_id;
  6:required string title;
  7:string subtitle;
  8:string title_other;
  9:string title_en;
  10:string actor;  //演员表|主持人|歌手|配音, 多个用“;”分开
  11:string actor_id;
  12:string director;
  13:string director_id;
  14:string writer;
  15:string writer_id;
  16:string showtime;
  17:i32 showyear;
  18:string area;
  19:string subcategory;
  20:string subcategory_id;
  21:string language;
  22:i32 language_id;
  23:string fit_age;
  24:string fit_age_id;
  25:string short_description;
  26:string description;
  27:string tags;
  28:string poster;
  29:i64 collects;
  30:double rating;
  31:i32 commentator;
  32:i32 episodes;
  33:i32 is_end;
  34:string play_url;
  35:i32 quality;
  36:string duration;
  37:i32 copyright;
  38:i32 state;
  39:string type;
  40:i32 type_id;
  41:string version;
  42:i32 version_id;
  43:i32 is_pay;
  44:i64 play_day_total;
  45:i64 play_week_total;
  46:i64 play_month_total;
  47:i64 play_season_total;
  48:i64 play_year_total;
  49:i64 play_total;
  50:i64 create_time;
  51:i64 update_time;
  52:i64 delete_time;
  53:string platform_download;
  54:string platform_play;
  55:string platform_pay;
  56:string publish_status;
  57:string douban_id;
  58:list<MediaVideoAbstract> videos;
  59:string play_stream;
  60:i32 is_edit;
  61:map<string, string> extend;
  62:i32 now_episode;
  63:string area_id;  64:string starring;
  65:string starring_id;
  66:optional string play_control_platform;
}

